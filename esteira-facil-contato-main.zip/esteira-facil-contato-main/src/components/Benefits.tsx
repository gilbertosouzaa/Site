import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const benefits = [
  {
    icon: "🛡️",
    title: "Proteção Completa",
    description: "Protege seus equipamentos contra poeira, umidade e desgaste"
  },
  {
    icon: "💪",
    title: "Material Resistente", 
    description: "Fabricado com materiais de alta qualidade e longa durabilidade"
  },
  {
    icon: "📏",
    title: "Tamanhos Variados",
    description: "Disponível em diversos tamanhos ou sob medida"
  },
  {
    icon: "💰",
    title: "Melhor Preço",
    description: "Nós fábricamos nosso próprio produto, garantia de qualidade."
  },
  {
    icon: "🚚",
    title: "Entrega Rápida",
    description: "Entregamos em todo o Brasil com agilidade - consultar frete"
  },
  {
    icon: "✅",
    title: "Qualidade Garantida",
    description: "Produtos testados e aprovados por academias profissionais"
  }
];

const Benefits = () => {
  return (
    <section id="beneficios" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-foreground">
            Por que Escolher Nossas Lonas?
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Nossos produtos oferecem a melhor proteção para seus equipamentos, 
            com qualidade comprovada e preço justo.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <Card 
              key={index}
              className="bg-gradient-card shadow-soft hover:shadow-medium transition-all duration-300 transform hover:-translate-y-1 text-center"
            >
              <CardHeader className="pb-4">
                <div className="text-4xl mb-4">{benefit.icon}</div>
                <CardTitle className="text-xl font-bold text-primary">
                  {benefit.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {benefit.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-gradient-hero text-white rounded-xl p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Garantia de Satisfação</h3>
          <p className="text-lg opacity-90 max-w-2xl mx-auto">
            Garantia de até 6 meses sem acidente. Estamos confiantes na qualidade 
            dos nossos produtos!
          </p>
        </div>
      </div>
    </section>
  );
};

export default Benefits;