import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const Contact = () => {
  const handleWhatsAppContact = () => {
    const message = "Olá! Gostaria de tirar algumas dúvidas sobre as lonas para esteira.";
    const phone = "5588981153100";
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleCallContact = () => {
    window.open('tel:+5588981153100', '_self');
  };

  return (
    <section id="contato" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-foreground">
            Entre em Contato
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Tem dúvidas? Precisa de um orçamento? Estamos aqui para ajudar!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <div className="space-y-8">
            <Card className="bg-gradient-card shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-primary">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.108"/>
                  </svg>
                  WhatsApp
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Fale conosco pelo WhatsApp para atendimento rápido e personalizado.
                </p>
                <Button 
                  variant="whatsapp" 
                  className="w-full"
                  onClick={handleWhatsAppContact}
                >
                  Chamar no WhatsApp
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-primary">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19.95 21q-3.125 0-6.175-1.362-3.05-1.363-5.425-3.738-2.375-2.375-3.737-5.425Q3.25 7.425 3.25 4.3q0-.45.3-.75t.75-.3H8.1q.35 0 .625.238.275.237.325.587l.65 3.5q.05.4-.025.675Q9.6 8.525 9.3 8.775l-2.175 2.2q1.05 1.8 2.638 3.387Q11.35 15.95 13.1 17l2.3-2.3q.225-.225.588-.337.362-.113.712-.063l3.45.7q.35.075.575.337Q20.95 15.6 20.95 16v3.7q0 .45-.3.75t-.7.3ZM6.025 9l1.65-1.65L7.25 5H5.025q.125 1.025.35 2.025.225 1 .65 2Zm8.95 8.95q.975.425 1.988.675 1.012.25 2.037.375v-2.175l-2.35-.475-1.675 1.6Z"/>
                  </svg>
                  Telefone
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Prefere falar por telefone? Ligue agora mesmo!
                </p>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={handleCallContact}
                >
                  (88) 98115-3100
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-hero text-white rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-6">Horário de Atendimento</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Todos os dias:</span>
                  <span>08:00 - 20:00</span>
                </div>
              </div>
            </div>

            <div className="bg-muted/50 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-6 text-foreground">Informações Importantes</h3>
              <div className="space-y-4 text-muted-foreground">
                <div className="flex items-start gap-3">
                  <span className="text-secondary text-xl">✓</span>
                  <span>Orçamentos gratuitos e sem compromisso</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-secondary text-xl">✓</span>
                  <span>Entrega para todo o Brasil</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-secondary text-xl">✓</span>
                  <span>Pagamento facilitado</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-secondary text-xl">✓</span>
                  <span>Garantia de qualidade</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;