import { Button } from "@/components/ui/button";
import heroMat from "@/assets/hero-mat.jpg";

const Hero = () => {
  const handleWhatsAppContact = () => {
    const message = "Olá! Quero conhecer os preços das lonas para esteira.";
    const phone = "5511999999999"; // Substitua pelo número real
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <section className="relative bg-gradient-hero text-white py-20 overflow-hidden">
      <div className="absolute inset-0 bg-black/40"></div>
      
      <div className="relative container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
          Lonas para Esteira
          <span className="block text-secondary">de Academia</span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-90">
          Proteja seus equipamentos com nossas lonas de alta qualidade. 
          Todos os tamanhos disponíveis com o melhor preço do mercado!
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            variant="hero" 
            size="lg"
            onClick={handleWhatsAppContact}
            className="text-lg px-8 py-4"
          >
            Ver Preços no WhatsApp
          </Button>
          
          <Button 
            variant="outline" 
            size="lg"
            className="text-lg px-8 py-4 bg-white/10 border-white/30 text-white hover:bg-white/20"
            onClick={() => document.getElementById('produtos')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Ver Produtos
          </Button>
        </div>
        
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-2">Material Premium</h3>
            <p className="opacity-90">Alta resistência e durabilidade</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-2">Todos os Tamanhos</h3>
            <p className="opacity-90">Sob medida para sua necessidade</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-2">Melhor Preço</h3>
            <p className="opacity-90">Direto da fábrica para você</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;