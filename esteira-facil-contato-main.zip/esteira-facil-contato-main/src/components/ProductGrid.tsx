import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Product {
  id: string;
  name: string;
  size: string;
  price: string;
  description: string;
  popular?: boolean;
}

const products: Product[] = [
  {
    id: "1",
    name: "Movement Lx 160 G3",
    size: "",
    price: "R$ 270,00",
    description: "Ideal para esteiras residenciais e equipamentos menores"
  },
  {
    id: "2",
    name: "Movement R4",
    size: "", 
    price: "R$ 159,00",
    description: "Perfeita para academias de médio porte",
    popular: true
  },
  {
    id: "3",
    name: "Movement R5i",
    size: "",
    price: "R$ 309,00", 
    description: "Para academias profissionais e espaços maiores"
  },
  {
    id: "4",
    name: "Dream Fitness DR2110",
    size: "",
    price: "R$ 169,00",
    description: "Cobertura completa para áreas extensas"
  },
  {
    id: "5",
    name: "Lona Personalizada",
    size: "Sob medida",
    price: "Consulte",
    description: "Fazemos no tamanho exato que você precisa"
  },
  {
    id: "6",
    name: "Kit 3 Lonas",
    size: "Tamanhos variados",
    price: "Com desconto",
    description: "Economize comprando o kit completo"
  }
];

const ProductGrid = () => {
  const handleWhatsAppOrder = (product: Product) => {
    const message = `Olá! Tenho interesse na ${product.name} (${product.size}) por ${product.price}. Gostaria de mais informações.`;
    const phone = "5588981153100";
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <section id="produtos" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-foreground">
            Nossos Produtos
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Escolha o tamanho ideal para sua academia. Todos os produtos com qualidade garantida e preço justo.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card 
              key={product.id} 
              className={`relative bg-gradient-card shadow-soft hover:shadow-medium transition-all duration-300 transform hover:-translate-y-1 ${
                product.popular ? 'ring-2 ring-secondary' : ''
              }`}
            >
              {product.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-secondary text-secondary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                    Mais Popular
                  </span>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold text-primary">
                  {product.name}
                </CardTitle>
                <div className="space-y-2">
                  <p className="text-lg font-semibold text-muted-foreground">
                    {product.size}
                  </p>
                  <p className="text-3xl font-bold text-primary">
                    {product.price}
                  </p>
                </div>
              </CardHeader>
              
              <CardContent className="text-center space-y-4">
                <p className="text-muted-foreground">
                  {product.description}
                </p>
                
                <Button 
                  variant="whatsapp"
                  className="w-full"
                  onClick={() => handleWhatsAppOrder(product)}
                >
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.108"/>
                  </svg>
                  Pedir no WhatsApp
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-lg text-muted-foreground mb-4">
            Precisa de um tamanho específico? Fazemos sob medida!
          </p>
          <Button 
            variant="secondary"
            size="lg"
            onClick={() => {
              const message = "Olá! Preciso de uma lona sob medida. Podem me ajudar com um orçamento?";
              const phone = "5588981153100";
              const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
              window.open(url, '_blank');
            }}
          >
            Solicitar Orçamento Personalizado
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;