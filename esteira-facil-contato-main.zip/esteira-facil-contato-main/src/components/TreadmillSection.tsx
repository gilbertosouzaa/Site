import heroMat from "@/assets/hero-mat.jpg";

const TreadmillSection = () => {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <img 
            src={heroMat} 
            alt="Esteira de academia com lona protetora" 
            className="w-full h-auto rounded-lg shadow-lg object-contain"
          />
        </div>
      </div>
    </section>
  );
};

export default TreadmillSection;